<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>jQuery Print Area</title>
<meta name="description" content="jQuery Print Area" />
<meta name="keywords" content="jQuery Print Area" />
<meta http-equiv="imagetoolbar" content="no" />
<link href="/css/core.css" rel="stylesheet" media="screen" type="text/css" />
<link href="/css/core.css" rel="stylesheet" media="print" type="text/css" />
</head>
<body>



<script src="/js/jquery-1.6.2.min.js"></script>
<script src="/js/jquery.PrintArea.js_4.js"></script>
<script src="/js/core.js"></script>
</body>
</html>